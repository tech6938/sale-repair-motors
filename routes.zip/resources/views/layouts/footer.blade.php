<div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright">&copy; {{ date('Y') }} {{ config('app.name') }}</a></div>
        </div>
    </div>
</div>
