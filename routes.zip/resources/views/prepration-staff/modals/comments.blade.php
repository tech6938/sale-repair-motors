<h5 class="title pb-3">Comments</h5>

<div class="row gy-4">
    <div class="col-md-12">
        <div class="form-group">
            <p>{!! canEmpty($staffs->admin_comments) !!}</p>
        </div>
    </div>
</div>
