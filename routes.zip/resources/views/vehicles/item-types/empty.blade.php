<div class="col-md-12">
    <p style="font-style: italic; font-weight: 600;">No Content Available</p>
</div>
