<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\LayoutServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
    Spatie\Permission\PermissionServiceProvider::class,
];
