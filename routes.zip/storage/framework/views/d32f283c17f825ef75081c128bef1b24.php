<div class="nk-footer nk-auth-footer-full">
    <div class="container">
        <div class="row g-3">
            <div class="col-lg-12">
                <div class="nk-block-content text-center text-lg-left">
                    <p class="text-soft">&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\firstwork\debugger\Vehicle Project\resources\views/layouts/auth/footer.blade.php ENDPATH**/ ?>