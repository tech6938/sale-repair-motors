<div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright">&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?></a></div>
        </div>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\JULY\Car\resources\views/layouts/footer.blade.php ENDPATH**/ ?>