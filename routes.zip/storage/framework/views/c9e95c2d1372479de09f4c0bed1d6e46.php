<div class="col-md-12">
    <p style="font-style: italic; font-weight: 600;">No Content Available</p>
</div>
<?php /**PATH C:\xampp\htdocs\firstwork\Vehicle Project\resources\views/vehicles/item-types/empty.blade.php ENDPATH**/ ?>