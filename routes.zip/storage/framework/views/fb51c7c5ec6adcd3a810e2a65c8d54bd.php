<?php $__env->startSection('title', 'Vehicles Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <div class="nk-block-head-sub">
                    <a class="back-to" href="<?php echo e(route('vehicles.index')); ?>">
                        <em class="icon ni ni-arrow-left"></em>
                        <span>Back to Listing</span>
                    </a>
                </div>
                <h3 class="nk-block-title page-title"><?php echo e(implode(' ', [$vehicle->make, $vehicle->model])); ?> Details</h3>
            </div>

            <div class="nk-block-head-content">
                <div class="toggle-wrap nk-block-tools-toggle">
                    <a href="javascript:void(0);" class="btn btn-icon btn-trigger toggle-expand me-n1" data-target="pageMenu">
                        <em class="icon ni ni-more-v"></em>
                    </a>
                    <div class="toggle-expand-content" data-content="pageMenu">
                        <ul class="nk-block-tools g-3">
                            <li class="nk-block-tools-opt">
                                <a href="<?php echo e(route('vehicles.export', $vehicle->uuid)); ?>" class="btn btn-primary" target="_blank">
                                    <em class="icon ni ni-download"></em>
                                    <span>Export PDF</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="nk-block">
        <div class="card card-bordered card-preview">
            <div class="card-inner">
                <div class="row">
                    <div class="col-12">
                        <div class="nk-block">

                            
                            <div class="nk-block-head">
                                <div class="nk-block-between">
                                    <div class="nk-block-head-content">
                                        <h3 class="nk-block-title title">
                                            <?php echo e(implode(' ', [$vehicle->make, $vehicle->model])); ?>

                                            <span style="font-size: 0.6em;"><?php echo e($vehicle->year); ?></span>
                                        </h3>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                
                                <div class="col-lg-6">
                                    <ul class="data-list is-compact">
                                        <li class="py-1 px-3">
                                            <div class="data-col">
                                                <div class="data-label">
                                                    <h6>Fuel Type</h6>
                                                </div>
                                                <div class="data-value"><?php echo e(ucwords($vehicle->fuel_type)); ?></div>
                                            </div>
                                        </li>
                                        <li class="py-1 px-3">
                                            <div class="data-col">
                                                <div class="data-label">
                                                    <h6>Color</h6>
                                                </div>
                                                <div class="data-value"><?php echo e($vehicle->color); ?></div>
                                            </div>
                                        </li>
                                        <li class="py-1 px-3">
                                            <div class="data-col">
                                                <div class="data-label">
                                                    <h6>Milage</h6>
                                                </div>
                                                <div class="data-value"><?php echo e($vehicle->milage); ?></div>
                                            </div>
                                        </li>
                                        <li class="py-1 px-3">
                                            <div class="data-col">
                                                <div class="data-label">
                                                    <h6>Registration</h6>
                                                </div>
                                                <div class="data-value"><?php echo e($vehicle->registration); ?></div>
                                            </div>
                                        </li>
                                        <li class="py-1 px-3">
                                            <div class="data-col">
                                                <div class="data-label">
                                                    <h6>Created At</h6>
                                                </div>
                                                <div class="data-value"><?php echo e($vehicle->createdAt()); ?></div>
                                            </div>
                                        </li>
                                        <li class="py-1 px-3">
                                            <div class="data-col">
                                                <div class="data-label">
                                                    <h6>Updated At</h6>
                                                </div>
                                                <div class="data-value"><?php echo $vehicle->updatedAt(); ?></div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                                
                                <div class="col-lg-6">
                                    <ul class="data-list is-compact">
                                        <li class="py-1 px-3">
                                            <div class="data-col">
                                                <div class="data-label">
                                                    <h6>Inspection Started At</h6>
                                                </div>
                                                <div class="data-value"><?php echo frontendDateTime($vehicle->inspections->first()?->started_at); ?></div>
                                            </div>
                                        </li>
                                        <li class="py-1 px-3">
                                            <div class="data-col">
                                                <div class="data-label">
                                                    <h6>Inspection Completed At</h6>
                                                </div>
                                                <div class="data-value"><?php echo frontendDateTime($vehicle->inspections->first()?->completed_at); ?></div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-aside-wrap">
                
                <div class="card-aside card-aside-left user-aside toggle-slide toggle-slide-left toggle-break-lg toggle-screen-lg" data-content="userAside" data-toggle-screen="lg"
                    data-toggle-overlay="true">
                    <div class="card-inner-group" data-simplebar="init">
                        <div class="simplebar-wrapper" style="margin: 0px;">
                            <div class="simplebar-height-auto-observer-wrapper">
                                <div class="simplebar-height-auto-observer"></div>
                            </div>
                            <div class="simplebar-mask">
                                <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                    <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: auto;">

                                        <div class="card-inner p-0">
                                            <ul class="link-list-menu">
                                                <?php $__currentLoopData = $checklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $checklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a class="nav-link checklist" href="<?php echo e(route('vehicles.checklist', [$vehicle->uuid, $checklist->uuid])); ?>" async-view>
                                                            <span><?php echo e($checklist->title); ?></span>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="simplebar-placeholder" style="width: auto; height: <?php echo e($checklists->count() * 54 + 10); ?>px"></div>
                        </div>
                        <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                            <div class="simplebar-scrollbar simplebar-visible" style="width: 0px; display: none;"></div>
                        </div>
                        <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                            <div class="simplebar-scrollbar simplebar-visible" style="height: 0px; display: none;"></div>
                        </div>
                    </div>
                </div>

                <div class="card-inner card-inner-lg">
                    <div class="tab-content">
                        <div class="tab-pane active">
                            <div class="nk-block-head nk-block-head-lg pb-0">
                                <div class="nk-block-between">
                                    <div class="nk-block-head-content">
                                        <h4 class="nk-block-title">Checklist Details</h4>
                                    </div>
                                    <div class="nk-block-head-content align-self-start d-lg-none">
                                        <a href="javascript:void(0);" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside">
                                            <em class="icon ni ni-menu-alt-r"></em>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="nk-data data-list" id="async-view-container"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {
            $('.checklist').first().click();
        });

        $(document).on('click', '.checklist', function() {
            let overlay = $(document).find('.toggle-overlay[data-target="userAside"]');

            if (overlay?.length > 0) {
                overlay.remove();
                $('.user-aside')?.removeClass('content-active');
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\firstwork\Vehicle Project\resources\views/vehicles/show.blade.php ENDPATH**/ ?>