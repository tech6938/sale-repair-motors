<!DOCTYPE html>
<html lang="en" class="js">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="author" content="Taimoor Ali">
    <meta name="description" content="Cloud-based system for submitting vehicle inspections with media, reviewed through app.">

    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme.min.css?ver=3.2.3')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <script>
        let fallbackThumbnail = "<?php echo e(asset('assets/images/placeholder.jpg')); ?>";

        // Bind image on error. ie = Image Error
        function _ie(_self) {
            _self.src = fallbackThumbnail;
        }
    </script>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="nk-body bg-lighter npc-default has-sidebar <?php echo e($isDarkMode ? 'dark-mode' : ''); ?>">
    <div class="nk-app-root">
        <div class="nk-main ">
            <?php echo $__env->make('layouts.partials.full-screen-spinner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="nk-wrap ">
                <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <?php echo $__env->make('layouts.partials.user-notices', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->

                <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>
        </div>
    </div>
    <!-- app-root @e -->

    <!-- Async modal @s -->
    <div class="modal fade zoom" id="async-modal" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <a href="javascript:void(0);" class="close" async-modal-close>
                    <em class="icon ni ni-cross"></em>
                </a>
                <div class="modal-body modal-body-lg">
                    <div id="content"></div>
                    <div id="spinner">
                        <div class="modal-body text-center">
                            <div class="spinner-border text-center" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Async modal @e -->

    <!-- JavaScript -->
    <script src="<?php echo e(asset('assets/js/bundle.js?ver=3.2.3')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js?ver=3.2.3')); ?>"></script>

    <script>
        $.extend(true, $.fn.dataTable.defaults, {
            oLanguage: {
                sSearch: '',
                sSearchPlaceholder: 'Type in to Search',
                sLengthMenu: 'Show _MENU_',
            }
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\firstwork\debugger\Vehicle Project\resources\views/layouts/app.blade.php ENDPATH**/ ?>