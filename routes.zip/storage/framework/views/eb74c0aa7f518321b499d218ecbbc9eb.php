<div class="row g-gs">
    <h5 class="nk-block-title"><?php echo e($checklist->title); ?></h5>

    <?php if($items->count() == 0): ?>
        <?php echo $__env->make('vehicles.item-types.empty', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(empty($item->checklistItemResults->first())): ?>
            <?php echo $__env->make('vehicles.item-types.empty', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if($item->item_type === 'multiselect'): ?>
                <?php break; ?>
            <?php endif; ?>

            <?php continue; ?>
        <?php endif; ?>

        <?php if($item->item_type == 'image'): ?>
            <?php echo $__env->make('vehicles.item-types.image', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <?php if($item->item_type == 'multi_image'): ?>
            <?php echo $__env->make('vehicles.item-types.multi-image', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <?php if($item->item_type == 'video'): ?>
            <?php echo $__env->make('vehicles.item-types.video', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <?php if($item->item_type == 'text'): ?>
            <?php echo $__env->make('vehicles.item-types.text', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <?php if($item->item_type == 'number'): ?>
            <?php echo $__env->make('vehicles.item-types.number', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <?php if($item->item_type == 'boolean'): ?>
            <?php echo $__env->make('vehicles.item-types.boolean', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <?php if($item->item_type == 'select'): ?>
            <?php echo $__env->make('vehicles.item-types.select', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <?php if($item->item_type == 'multiselect'): ?>
            <?php echo $__env->make('vehicles.item-types.multiselect', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\firstwork\Vehicle Project\resources\views/vehicles/checklist.blade.php ENDPATH**/ ?>