<div class="brand-logo pb-4 text-center">
    <a href="<?php echo e(url('/')); ?>" class="logo-link">
        <img class="logo-light logo-img logo-img-lg" src="<?php echo e(asset('assets/images/logo.png')); ?>" srcset="<?php echo e(asset('assets/images/logo2x.png')); ?> 2x" alt="logo">
        <img class="logo-dark logo-img logo-img-lg" src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" srcset="<?php echo e(asset('assets/images/logo-dark2x.png')); ?> 2x" alt="logo-dark">
    </a>
</div>
<?php /**PATH C:\xampp\htdocs\firstwork\Vehicle Project\resources\views/layouts/auth/header.blade.php ENDPATH**/ ?>