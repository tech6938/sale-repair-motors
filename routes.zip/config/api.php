<?php

return [

    /*
    |--------------------------------------------------------------------------
    | This configuration file is for RESTful APIs
    |--------------------------------------------------------------------------
    |
    | Here you may define the api key that will be applied to all the API routes
    |
    */

    'key' => env('API_KEY', ''),

];
