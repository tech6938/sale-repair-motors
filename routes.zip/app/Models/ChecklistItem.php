<?php

namespace App\Models;

use App\Models\Concerns\HasUuid;
use App\Models\Concerns\Timestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChecklistItem extends Model
{
    use HasFactory, HasUuid, Timestamps;

    public const ITEM_TYPE_IMAGE = 'image';
    public const ITEM_TYPE_MULTI_IMAGE = 'multi_image';
    public const ITEM_TYPE_VIDEO = 'video';
    public const ITEM_TYPE_TEXT = 'text';
    public const ITEM_TYPE_NUMBER = 'number';
    public const ITEM_TYPE_BOOLEAN = 'boolean';
    public const ITEM_TYPE_SELECT = 'select';
    public const ITEM_TYPE_MULTISELECT = 'multiselect';

    protected $fillable = [
        'id',
        'inspection_checklist_id',
        'uuid',
        'title',
        'description',
        'item_type',
        'display_order',
        'is_required',
        'min',
        'max',
    ];

    protected $casts = [
        'display_order' => 'integer',
        'is_required' => 'boolean',
        'min' => 'integer',
        'max' => 'integer',
    ];

    /**
     * Get the checklist that owns the ChecklistItem
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function inspectionChecklist()
    {
        return $this->belongsTo(InspectionChecklist::class);
    }

    /**
     * Get the item options that belong to the ChecklistItem
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function itemOptions()
    {
        return $this->hasMany(ItemOption::class);
    }

    /**
     * Get the checklist item results that belong to the ChecklistItem
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function checklistItemResults()
    {
        return $this->hasMany(ChecklistItemResult::class);
    }

    /**
     * Scope a query to only include required checklist items.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeRequired($query)
    {
        return $query->where('is_required', true);
    }

    /**
     * Scope a query to only include optional checklist items.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOptional($query)
    {
        return $query->where('is_required', false);
    }

    /**
     * Scope a query to order the checklist items by their display order.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOrdered($query)
    {
        return $query->orderBy('display_order');
    }
}
