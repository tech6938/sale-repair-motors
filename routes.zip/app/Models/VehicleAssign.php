<?php

namespace App\Models;

use App\Models\Concerns\HasUuid;
use Illuminate\Database\Eloquent\Model;

class VehicleAssign extends Model
{

    protected  $guarded = [];
}
