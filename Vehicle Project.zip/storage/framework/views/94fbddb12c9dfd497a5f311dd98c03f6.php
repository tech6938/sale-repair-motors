<!-- Fullscreen Spinner -->
<div id="fullscreen-spinner" class="spinner-overlay">
    <div class="spinner-border text-light" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<!-- End Fullscreen Spinner -->
<?php /**PATH E:\xampp\htdocs\JULY\Car\resources\views/layouts/partials/full-screen-spinner.blade.php ENDPATH**/ ?>