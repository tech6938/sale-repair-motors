<?php $__env->startSection('title', 'Vehicles Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">Vehicles Management</h3>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-bordered card-preview">
            <div class="card-inner overflow-x-scroll">
                <table id="vehicles-dt" class="table nowrap nk-tb-list nk-tb-ulist dataTable no-footer" width="100%">
                    <thead>
                        <tr class="nk-tb-item nk-tb-head">
                            <th><span class="sub-text">#</span></th>
                            <?php if(auth()->user()->isSuperAdmin()): ?>
                                <th><span class="sub-text">Manager</span></th>
                            <?php endif; ?>
                            <th><span class="sub-text">Vehicle</span></th>
                            <th><span class="sub-text">Registration</span></th>
                            <th><span class="sub-text">Inspection Started At</span></th>
                            <th><span class="sub-text">Inspection Completed At</span></th>
                            <th><span class="sub-text">Vehicle Created</span></th>
                            <th><span class="sub-text">Vehicle Updated</span></th>
                            <th class="text-right"><span class="sub-text">Actions</span></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        let columns = [{
                data: 'DT_RowIndex',
                name: 'uuid',
                orderable: false,
                searchable: false
            },
            {
                data: 'vehicle',
                name: 'vehicle'
            },
            {
                data: 'registration',
                name: 'registration'
            },
            {
                data: 'started_at',
                name: 'started_at',
                searchable: false
            },
            {
                data: 'completed_at',
                name: 'completed_at',
                searchable: false
            },
            {
                data: 'created',
                name: 'created',
                searchable: false
            },
            {
                data: 'updated',
                name: 'updated',
                searchable: false
            },
            {
                data: 'actions',
                name: 'actions',
                searchable: false
            },
        ];

        <?php if(auth()->user()->isSuperAdmin()): ?>
            columns.splice(1, 0, {
                data: 'manager',
                name: 'manager',
                orderable: false,
                searchable: false
            });
        <?php endif; ?>

        let dt = $('#vehicles-dt').DataTable({
            processing: true,
            serverSide: true,
            scrollX: false,
            ordering: false,
            autoWidth: true,
            ajax: {
                url: "<?php echo e(route('vehicles.datatable')); ?>",
            },
            columns: columns,
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\firstwork\Vehicle Project\resources\views/vehicles/index.blade.php ENDPATH**/ ?>