<!DOCTYPE html>
<html lang="en" class="js">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="author" content="Taimoor Ali">
    <meta name="description" content="Cloud-based system for submitting vehicle inspections with media, reviewed through app.">

    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme.min.css?ver=3.2.3')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="nk-body ui-rounder npc-default pg-auth">
    <!-- app-root @s -->
    <div class="nk-app-root">
        <div class="nk-main">
            <!-- wrap @s -->
            <div class="nk-wrap nk-wrap-nosidebar">
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="nk-block nk-block-middle nk-auth-body  wide-xs">
                        <?php echo $__env->make('layouts.auth.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                    <?php echo $__env->make('layouts.auth.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <!-- content @e -->
            </div>
            <!-- wrap @e -->
        </div>
    </div>
    <!-- app-root @e -->

    <!-- JavaScript -->
    <script src="<?php echo e(asset('assets/js/bundle.js?ver=3.2.3')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js?ver=3.2.3')); ?>"></script>

    <script>
        $(document).on('submit', 'form', function(e) {
            $(this)
                .find('button')
                .prop('disabled', true)
                .prepend('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');

            const forms = $(this).siblings('form');

            if (forms.length > 0) {
                forms
                    .find('button')
                    .prop('disabled', true);
            }
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH E:\xampp\htdocs\JULY\Car\resources\views/layouts/auth/app.blade.php ENDPATH**/ ?>