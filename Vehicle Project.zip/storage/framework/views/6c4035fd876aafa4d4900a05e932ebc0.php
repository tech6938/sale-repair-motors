<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible mb-4">
        <button class="close" data-bs-dismiss="alert"></button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    <div class="alert alert-danger alert-icon alert-dismissible mb-4 alert-auto-hide">
        <em class="icon ni ni-cross-circle"></em> <strong>Oops</strong>! <?php echo e(session('error')); ?> <button class="close" data-bs-dismiss="alert"></button>
    </div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

<?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    <div class="alert alert-success alert-icon alert-dismissible mb-4 alert-auto-hide">
        <em class="icon ni ni-check-circle"></em> <strong>Hurray</strong>! <?php echo e(session('success')); ?> <button class="close" data-bs-dismiss="alert"></button>
    </div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
<?php /**PATH E:\xampp\htdocs\JULY\Car\resources\views/layouts/partials/user-notices.blade.php ENDPATH**/ ?>