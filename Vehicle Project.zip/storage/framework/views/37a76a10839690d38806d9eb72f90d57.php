<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-bordered">
        <div class="card-inner card-inner-lg">
            <div class="nk-block-head">
                <div class="nk-block-head-content">
                    <h4 class="nk-block-title">Sign-In</h4>
                    <div class="nk-block-des">
                        <p>Access the application panel using your email and password.</p>
                    </div>
                </div>
            </div>

            <?php if(session('status')): ?>
                <div class="alert alert-info"><?php echo e(session('status')); ?></div>
            <?php endif; ?>

            <form method="post" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <div class="form-label-group">
                        <label class="form-label" for="email">Email</label>
                    </div>
                    <div class="form-control-wrap">
                        <input type="email" class="form-control form-control-lg" id="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus
                            placeholder="Enter your email address">
                        <?php if($errors->has('email')): ?>
                            <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="form-label-group">
                        <label class="form-label" for="password">Password</label>
                        <?php if(Route::has('password.request')): ?>
                            <a class="link link-primary link-sm" href="<?php echo e(route('password.request')); ?>" tabindex="-1">Forgot Password?</a>
                        <?php endif; ?>
                    </div>
                    <div class="form-control-wrap">
                        <a href="javascript:void(0);" class="form-icon form-icon-right passcode-switch lg" data-target="password" tabindex="-1">
                            <em class="passcode-icon icon-show icon ni ni-eye"></em>
                            <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                        </a>
                        <input type="password" class="form-control form-control-lg" id="password" name="password" required placeholder="Enter your password">
                        <?php if($errors->has('password')): ?>
                            <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="custom-control custom-control-xs custom-checkbox">
                        <input type="checkbox" class="custom-control-input" name="remember" id="remember">
                        <label class="custom-control-label" for="remember">Remember me</label>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-lg btn-primary btn-block">
                        <span>Sign in</span>
                    </button>
                </div>
            </form>

            <?php if(Route::has('register')): ?>
                <div class="form-note-s2 text-center pt-4">
                    New on our platform? <a href="<?php echo e(route('register')); ?>">Create an account</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\firstwork\Vehicle Project\resources\views/auth/login.blade.php ENDPATH**/ ?>