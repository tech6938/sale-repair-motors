<div class="nk-footer nk-auth-footer-full">
    <div class="container">
        <div class="row g-3">
            <div class="col-lg-12">
                <div class="nk-block-content text-center text-lg-left">
                    <p class="text-soft">&copy; {{ date('Y') }} {{ config('app.name') }}.</p>
                </div>
            </div>
        </div>
    </div>
</div>
